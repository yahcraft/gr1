package Program.Model;

public class GameSettingMenu {
    User user;





    ////methods////
    public GameSettingMenu(User user)
    {
        this.user = user;
    }



    //getters
    public User getUser()
    {
        return user;
    }
}
