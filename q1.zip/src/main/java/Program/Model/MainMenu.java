package Program.Model;

public class MainMenu {
    private User user;





    ////methods////
    public MainMenu(User user)
    {
        this.user = user;
    }



    public User getUser()
    {
        return user;
    }
}
