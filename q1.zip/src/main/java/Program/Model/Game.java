package Program.Model;

public class Game {
    User user;





    ////methods////
    public Game(User user)
    {
        this.user = user;
    }



    public User getUser()
    {
        return user;
    }
}
